notify-send "D&D Backup Tool" "D&D Backup Tool backs up directory it is stored in, including its own file and subdirectories. Filex can be found in BACKUP.zip"
zip -r BACKUP.zip ./
